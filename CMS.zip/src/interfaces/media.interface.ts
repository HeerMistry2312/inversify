import { Types } from "mongoose";

export default interface IMedia {
  _id?: Types.ObjectId;
  title: string;
  content: string;
  filename: string;
  path: string;
  author: Types.ObjectId;
  createdAt?: Date;
  updatedAt?: Date;
}

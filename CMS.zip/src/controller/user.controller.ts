import { injectable, inject } from "inversify";
import { NextFunction, Request, Response } from "express";
import {
  controller,
  httpGet,
  httpPost,
  httpPut,
  next,
  request,
  response,
} from "inversify-express-utils";
import mongoose from "mongoose";
import { UserService } from "../services/user.service";
import { TYPES } from "../types/types";
import StatusCode from "../enum/statusCode";

@controller("/user")
export class UserController {
  constructor(@inject(TYPES.UserService) private userService: UserService) {}
  @httpPost("/register")
  public async registerUser(
    @request() req: Request,
    @response() res: Response,
    @next() next: NextFunction
  ): Promise<void> {
    const session = await mongoose.startSession();
    await session.startTransaction();
    try {
      const { username, email, password, role } = req.body;
      const user = await this.userService.register(
        username,
        email,
        password,
        role,
        session
      );
      await session.commitTransaction();
      await session.endSession();
      res.status(StatusCode.OK).send(user);
    } catch (error) {
      await session.abortTransaction();
      await session.endSession();
      throw error;
    }
  }

  @httpPost("/login")
  public async loginUser(
    @request() req: Request,
    @response() res: Response,
    @next() next: NextFunction
  ): Promise<void> {
    const session = await mongoose.startSession();
    await session.startTransaction();
    try {
      const { username, password } = req.body;
      const user = await this.userService.login(username, password, session);
      await session.commitTransaction();
      await session.endSession();
      res.status(StatusCode.OK).send(user);
    } catch (error) {
      await session.abortTransaction();
      await session.endSession();
      throw error;
    }
  }

  @httpPut("/update", TYPES.AuthMiddleware)
  public async updateUser(
    @request() req: Request,
    @response() res: Response,
    @next() next: NextFunction
  ): Promise<void> {
    const session = await mongoose.startSession();
    await session.startTransaction();
    try {
      await session.commitTransaction();
      await session.endSession();
    //   res.status(StatusCode.OK).send(user);
    } catch (error) {
      await session.abortTransaction();
      await session.endSession();
      throw error;
    }
  }
}

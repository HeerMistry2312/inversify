import { injectable, inject } from "inversify";
import { NextFunction, Request, Response } from "express";
import {
  controller,
  httpDelete,
  httpGet,
  httpPost,
  httpPut,
  next,
  request,
  requestParam,
  response,
} from "inversify-express-utils";
import mongoose, { Types } from "mongoose";
import { TYPES } from "../types/types";
import StatusCode from "../enum/statusCode";
import MediaService from "../services/media.service";
import upload from "../utils/imageUpload";
import AppError from "../utils/appError";
import StatusConstants from "../constant/status.constant";

@controller("/media", TYPES.AuthMiddleware)
export class MediaController {
  constructor(@inject(TYPES.MediaService) private mediaService: MediaService) {}

  @httpPost("/:module/:action", TYPES.RoleMiddleware)
  public async createMedia(
    @requestParam("module") module: string,
    @requestParam("action") action: string,
    @request() req: Request,
    @response() res: Response,
    @next() next: NextFunction
  ): Promise<void> {
    const session = await mongoose.startSession();
    await session.startTransaction();
    upload(req, res, async (err: any) => {
      if (err) {
        throw new AppError(
          StatusConstants.BAD_REQUEST.body.message,
          StatusConstants.BAD_REQUEST.httpStatusCode
        );
      }

      if (!req.file) {
        throw new AppError(
          StatusConstants.BAD_REQUEST.body.message,
          StatusConstants.BAD_REQUEST.httpStatusCode
        );
      }
      const id = new Types.ObjectId(req.id);
      const { title, content } = req.body;
      const filename = req.file.filename;
      const path = req.file.path;
      try {
        const media = await this.mediaService.createMedia(
          { title, content, filename, path, author: id },
          session
        );
        res.status(201).json(media);
      } catch (error) {
        next(error);
      }
    });
  }
}
